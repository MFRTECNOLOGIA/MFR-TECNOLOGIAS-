package br.com.mfrmarket;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private DB db;
    private LinearLayout content;
    private final int RED = Color.rgb(190, 25, 45);
    private final int DARK = Color.rgb(25, 25, 25);
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("pt","BR"));

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        renderHome();
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(DARK);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 8, 0, 8);
        return t;
    }
    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true);
        e.setHint(hint); e.setInputType(type);
        return e;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label);
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void base(String subtitle) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22, 18, 22, 22);
        page.setBackgroundColor(Color.rgb(248,248,248));
        ScrollView scroll = new ScrollView(this); scroll.addView(page);
        TextView brand = text("MFR MARKET", 25, true); brand.setTextColor(RED);
        page.addView(brand);
        page.addView(text(subtitle, 15, false));
        LinearLayout nav = new LinearLayout(this);
        nav.addView(button("Início", this::renderHome), new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button("Produtos", this::renderProducts), new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button("Preços", this::renderPrices), new LinearLayout.LayoutParams(0,-2,1));
        page.addView(nav);
        View line = new View(this); line.setBackgroundColor(RED);
        page.addView(line, new LinearLayout.LayoutParams(-1,3));
        content = page;
        setContentView(scroll);
    }
    private void renderHome() {
        base("Gestão de produtos e pesquisa de preços");
        content.addView(text("Bem-vindo ao MFR Market", 21, true));
        content.addView(text("Organize seus produtos e registre preços encontrados em diferentes lojas e fornecedores.", 16, false));
        content.addView(text("Resumo",18,true));
        content.addView(text("Produtos cadastrados: " + db.count("products"),16,false));
        content.addView(text("Cotações registradas: " + db.count("prices"),16,false));
        content.addView(button("Cadastrar produto", this::renderProducts));
        content.addView(button("Registrar novo preço", this::renderPrices));
        content.addView(text("Versão inicial: os dados ficam armazenados neste aparelho.",13,false));
    }
    private void renderProducts() {
        base("Cadastro e consulta de produtos");
        content.addView(text("Novo produto",19,true));
        EditText name = field("Nome do produto", android.text.InputType.TYPE_CLASS_TEXT);
        EditText sku = field("Código / SKU (opcional)", android.text.InputType.TYPE_CLASS_TEXT);
        EditText category = field("Categoria (opcional)", android.text.InputType.TYPE_CLASS_TEXT);
        content.addView(name); content.addView(sku); content.addView(category);
        content.addView(button("Salvar produto", () -> {
            String n=name.getText().toString().trim();
            if(n.isEmpty()){ toast("Informe o nome do produto."); return; }
            db.addProduct(n, sku.getText().toString().trim(), category.getText().toString().trim());
            toast("Produto cadastrado."); renderProducts();
        }));
        content.addView(text("Produtos cadastrados",19,true));
        Cursor c=db.products();
        if(c.getCount()==0) content.addView(text("Nenhum produto cadastrado.",14,false));
        while(c.moveToNext()) {
            int id=c.getInt(0);
            content.addView(text(c.getString(1) + (c.getString(2).isEmpty()?"":"  •  "+c.getString(2)),16,true));
            content.addView(text(c.getString(3).isEmpty()?"Sem categoria":c.getString(3),13,false));
            content.addView(button("Excluir produto", () -> new AlertDialog.Builder(this)
                .setMessage("Excluir este produto e seus preços?")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Excluir",(d,w)->{db.deleteProduct(id);renderProducts();}).show()));
        }
        c.close();
    }
    private void renderPrices() {
        base("Registro de preços por loja ou fornecedor");
        content.addView(text("Nova cotação",19,true));
        Cursor products=db.products();
        java.util.ArrayList<String> labels=new java.util.ArrayList<>();
        java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();
        while(products.moveToNext()){ids.add(products.getInt(0)); labels.add(products.getString(1));}
        products.close();
        if(ids.isEmpty()) {
            content.addView(text("Cadastre um produto antes de registrar preços.",15,false));
            content.addView(button("Ir para produtos",this::renderProducts)); return;
        }
        Spinner spinner=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);
        spinner.setAdapter(adapter); content.addView(spinner);
        EditText store=field("Loja / fornecedor / marketplace",android.text.InputType.TYPE_CLASS_TEXT);
        EditText price=field("Preço (ex.: 129,90)",android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText url=field("Link do produto (opcional)",android.text.InputType.TYPE_TEXT_VARIATION_URI);
        EditText notes=field("Observações (opcional)",android.text.InputType.TYPE_CLASS_TEXT);
        content.addView(store); content.addView(price); content.addView(url); content.addView(notes);
        content.addView(button("Salvar preço",()->{
            String s=store.getText().toString().trim(), p=price.getText().toString().trim().replace(".","").replace(",",".");
            if(s.isEmpty()||p.isEmpty()){toast("Informe a loja e o preço.");return;}
            try {
                double value=Double.parseDouble(p);
                db.addPrice(ids.get(spinner.getSelectedItemPosition()),s,value,url.getText().toString().trim(),notes.getText().toString().trim());
                toast("Preço registrado."); renderPrices();
            } catch(Exception ex){toast("Confira o valor informado.");}
        }));
        content.addView(text("Últimos preços registrados",19,true));
        Cursor c=db.prices();
        if(c.getCount()==0) content.addView(text("Nenhum preço registrado.",14,false));
        while(c.moveToNext()) {
            content.addView(text(c.getString(1)+" — "+c.getString(2),16,true));
            content.addView(text(money.format(c.getDouble(3))+"  •  "+c.getString(4),14,false));
            if(!c.getString(5).isEmpty()) content.addView(text(c.getString(5),13,false));
        }
        c.close();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"mfr_market.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,sku TEXT,category TEXT)");
            d.execSQL("CREATE TABLE prices(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,store TEXT,price REAL,url TEXT,notes TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        int count(String table){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        void addProduct(String n,String s,String cat){ContentValues v=new ContentValues();v.put("name",n);v.put("sku",s);v.put("category",cat);getWritableDatabase().insert("products",null,v);}
        Cursor products(){return getReadableDatabase().rawQuery("SELECT id,name,sku,category FROM products ORDER BY name",null);}
        void deleteProduct(int id){getWritableDatabase().delete("prices","product_id=?",new String[]{String.valueOf(id)});getWritableDatabase().delete("products","id=?",new String[]{String.valueOf(id)});}
        void addPrice(int id,String store,double price,String url,String notes){ContentValues v=new ContentValues();v.put("product_id",id);v.put("store",store);v.put("price",price);v.put("url",url);v.put("notes",notes);getWritableDatabase().insert("prices",null,v);}
        Cursor prices(){return getReadableDatabase().rawQuery("SELECT p.id,pr.name,p.store,p.price,p.created_at,p.notes FROM prices p JOIN products pr ON pr.id=p.product_id ORDER BY p.id DESC",null);}
    }
}
