# MFR Market — projeto Android inicial

Projeto nativo Android (Java) para abrir no Android Studio e gerar um APK.

## O que já está implementado
- Cadastro local de produtos (nome, SKU e categoria).
- Registro manual de preços por loja, fornecedor ou marketplace.
- Campo opcional para link e observações.
- Histórico de cotações e resumo na tela inicial.
- Banco SQLite local no aparelho.

## Limitações desta primeira versão
- Ainda não há contas, login, painel administrativo remoto ou sincronização em nuvem.
- A captura de preços é manual: o aplicativo registra os valores informados; não consulta automaticamente Shopee, Mercado Livre ou Shein.
- Não há APK compilado neste pacote. O arquivo é o projeto-fonte para compilar no Android Studio.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `MFRMarket` pelo Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Para distribuir publicamente, gere uma versão assinada em **Build > Generate Signed Bundle / APK** e mantenha a chave de assinatura em segurança.

## Requisitos
- Android Studio recente.
- JDK 17.
- Android SDK Platform 35.
