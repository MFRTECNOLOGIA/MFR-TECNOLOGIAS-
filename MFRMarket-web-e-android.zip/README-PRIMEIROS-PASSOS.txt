MFR MARKET — PACOTE WEB + ANDROID

O QUE ESTÁ PRONTO
- Web app responsivo com identidade MFR (vermelho, preto e branco).
- Pode ser instalado como PWA quando publicado em HTTPS (menu do navegador > Instalar app / Adicionar à tela inicial).
- Cadastro de produtos, registro de preço e frete, link do anúncio, observações, comparação do menor total e exportação CSV.
- Funciona offline após primeira abertura; dados ficam no armazenamento do navegador/aparelho.
- Projeto Android nativo Java incluído na pasta android (versão inicial local).

IMPORTANTE — O QUE NÃO ESTÁ PRONTO
- Este pacote não contém URL pública ativa nem APK já compilado.
- O deploy e a compilação automatizados estão configurados para GitHub Actions, mas exigem que o proprietário crie um repositório GitHub e envie estes arquivos.
- O app atual não tem banco de dados compartilhado, login, painel remoto nem coleta automática de preços de marketplaces. A versão web guarda os dados no dispositivo. Integrações com Shopee, Mercado Livre e Shein dependem de APIs e credenciais/autorização dos respectivos serviços.
- O APK debug produzido pelo workflow é para teste. Para distribuição ampla, gerar APK assinado com uma chave de release protegida.

PUBLICAR E GERAR APK PELO GITHUB
1. Crie uma conta ou entre em https://github.com
2. Crie um repositório chamado mfr-market.
3. Envie todos os arquivos desta pasta para a branch main (pode usar Upload files no site do GitHub).
4. Abra Settings > Pages e selecione GitHub Actions como fonte, se solicitado.
5. Abra a aba Actions. Aguarde os fluxos "Build APK and publish web app".
6. O APK de teste ficará nos artefatos da execução do workflow (MFRMarket-APK-debug).
7. A URL pública do site ficará em Settings > Pages, após a conclusão do job web.
8. Abra a URL no Chrome Android e escolha Instalar app / Adicionar à tela inicial.

OBSERVAÇÃO
A URL pública não pode ser criada antes do repositório e da publicação. Não compartilhe dados sensíveis no app enquanto não houver autenticação e backend seguro.
